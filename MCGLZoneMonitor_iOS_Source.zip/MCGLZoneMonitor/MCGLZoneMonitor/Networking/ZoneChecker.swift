import Foundation
import Combine

@MainActor
final class ZoneChecker: ObservableObject {
    @Published private(set) var progress = ScanProgress()
    private var scanTask: Task<Void, Never>?
    private let baseURL = URL(string: "https://forum.minecraft-galaxy.ru/zoneinfo/")!

    func start(zones: [Zone], concurrency: Int, store: ZoneStore) {
        guard !progress.isRunning, !zones.isEmpty else { return }
        let limit = min(max(concurrency, 1), 150)
        progress = ScanProgress(total: zones.count, isRunning: true, message: "Проверка запущена")
        scanTask = Task {
            var iterator = zones.makeIterator()
            await withTaskGroup(of: (Int64, ZoneStatus, Int?, String?).self) { group in
                for _ in 0..<min(limit, zones.count) {
                    if let zone = iterator.next() { group.addTask { await Self.check(id: zone.id, baseURL: self.baseURL) } }
                }
                while let result = await group.next() {
                    let (id, status, code, error) = result
                    store.update(id, status: status, code: code, error: error)
                    progress.completed += 1
                    switch status {
                    case .exists: progress.exists += 1
                    case .deleted: progress.deleted += 1
                    case .unknown: progress.unknown += 1
                    }
                    progress.message = "Проверено \(progress.completed) из \(progress.total)"
                    if Task.isCancelled { group.cancelAll(); break }
                    if let next = iterator.next() {
                        group.addTask { await Self.check(id: next.id, baseURL: self.baseURL) }
                    }
                }
            }
            progress.isRunning = false
            progress.message = "Проверка завершена"
        }
    }

    func stop() {
        scanTask?.cancel()
        progress.isRunning = false
        progress.message = "Остановка запрошена"
    }

    private nonisolated static func check(id: Int64, baseURL: URL) async -> (Int64, ZoneStatus, Int?, String?) {
        let url = baseURL.appendingPathComponent(String(id))
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 20
        request.setValue("Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Version/17.0 Mobile/15E148 Safari/604.1", forHTTPHeaderField: "User-Agent")
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            let code = (response as? HTTPURLResponse)?.statusCode
            if code == 404 || code == 410 { return (id, .deleted, code, nil) }
            guard code == 200, let html = String(data: data, encoding: .utf8) else {
                return (id, .unknown, code, "Неоднозначный HTTP-ответ")
            }
            let body = html.lowercased()
            let deletedMarkers = ["зона не найдена", "зона не существует", "зона удалена", "zone not found", "zone does not exist"]
            if deletedMarkers.contains(where: body.contains) { return (id, .deleted, code, nil) }
            let existsMarkers = ["владелец", "создано", "посещено", "размер зоны"]
            if existsMarkers.contains(where: body.contains) { return (id, .exists, code, nil) }
            return (id, .unknown, code, "HTTP 200: шаблон страницы не распознан")
        } catch {
            return (id, .unknown, nil, error.localizedDescription)
        }
    }
}
