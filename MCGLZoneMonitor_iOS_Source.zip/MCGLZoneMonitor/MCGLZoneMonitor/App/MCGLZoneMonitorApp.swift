import SwiftUI

@main
struct MCGLZoneMonitorApp: App {
    @StateObject private var store = ZoneStore()
    @StateObject private var checker = ZoneChecker()

    var body: some Scene {
        WindowGroup {
            MainTabView()
                .environmentObject(store)
                .environmentObject(checker)
                .preferredColorScheme(.dark)
        }
    }
}
