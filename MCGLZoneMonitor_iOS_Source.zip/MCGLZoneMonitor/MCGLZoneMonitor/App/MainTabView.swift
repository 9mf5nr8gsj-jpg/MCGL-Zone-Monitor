import SwiftUI

struct MainTabView: View {
    var body: some View {
        TabView {
            DashboardView().tabItem { Label("Главная", systemImage: "square.grid.2x2") }
            ZonesView().tabItem { Label("База зон", systemImage: "map") }
            ScannerView().tabItem { Label("Парсер", systemImage: "antenna.radiowaves.left.and.right") }
            HistoryView().tabItem { Label("История", systemImage: "clock.arrow.circlepath") }
        }
        .tint(.cyan)
    }
}

struct DashboardView: View {
    @EnvironmentObject var store: ZoneStore
    private var exists: Int { store.zones.filter { $0.status == .exists }.count }
    private var deleted: Int { store.zones.filter { $0.status == .deleted }.count }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 14) {
                    HStack {
                        metric("Всего ID", value: store.zones.count, icon: "number")
                        metric("Существуют", value: exists, icon: "checkmark.circle")
                    }
                    HStack {
                        metric("Удалены", value: deleted, icon: "trash")
                        metric("Не проверены", value: store.zones.filter { $0.status == .unknown }.count, icon: "questionmark.circle")
                    }
                    Text("Мониторинг зон Minecraft Galaxy").font(.footnote).foregroundStyle(.secondary).padding(.top, 20)
                }.padding()
            }
            .navigationTitle("MCGL Zone Monitor")
        }
    }
    private func metric(_ title: String, value: Int, icon: String) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Label(title, systemImage: icon).font(.subheadline).foregroundStyle(.secondary)
            Text(value.formatted()).font(.system(size: 32, weight: .bold, design: .rounded))
        }.frame(maxWidth: .infinity, minHeight: 105, alignment: .leading).padding().background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 18))
    }
}

struct ZonesView: View {
    @EnvironmentObject var store: ZoneStore
    @State private var search = ""
    var filtered: [Zone] { store.zones.filter { search.isEmpty || String($0.id).contains(search) } }
    var body: some View {
        NavigationStack {
            List(filtered) { zone in
                HStack {
                    VStack(alignment: .leading) {
                        Text("Зона #\(zone.id)").fontWeight(.semibold)
                        Text(zone.lastChecked.map { "Проверена: \($0.formatted(date: .abbreviated, time: .shortened))" } ?? "Ещё не проверялась").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Text(zone.status.rawValue).font(.caption).padding(.horizontal, 9).padding(.vertical, 5).background(statusColor(zone.status).opacity(0.18), in: Capsule()).foregroundStyle(statusColor(zone.status))
                }
            }
            .searchable(text: $search, prompt: "Поиск по ID")
            .navigationTitle("База зон (\(store.zones.count))")
        }
    }
    private func statusColor(_ status: ZoneStatus) -> Color {
        switch status { case .exists: .green; case .deleted: .red; case .unknown: .orange }
    }
}

struct ScannerView: View {
    @EnvironmentObject var store: ZoneStore
    @EnvironmentObject var checker: ZoneChecker
    @State private var concurrency = 150.0
    @State private var importText = ""
    @State private var showingImport = false
    var body: some View {
        NavigationStack {
            Form {
                Section("Сканирование") {
                    HStack { Text("Параллельные запросы"); Spacer(); Text("\(Int(concurrency))").monospacedDigit().foregroundStyle(.cyan) }
                    Slider(value: $concurrency, in: 1...150, step: 1)
                    ProgressView(value: Double(checker.progress.completed), total: Double(max(checker.progress.total, 1)))
                    Text(checker.progress.message).font(.caption).foregroundStyle(.secondary)
                    HStack {
                        Label("\(checker.progress.completed)/\(checker.progress.total)", systemImage: "checkmark.circle")
                        Spacer(); Text("✓ \(checker.progress.exists)  ·  ✕ \(checker.progress.deleted)  ·  ? \(checker.progress.unknown)").font(.caption)
                    }
                    if checker.progress.isRunning {
                        Button(role: .destructive) { checker.stop() } label: { Label("Остановить", systemImage: "stop.fill") }
                    } else {
                        Button { checker.start(zones: store.zones.filter { $0.status != .deleted }, concurrency: Int(concurrency), store: store) } label: { Label("Проверить все зоны", systemImage: "play.fill") }
                            .disabled(store.zones.isEmpty)
                    }
                }
                Section("Добавить ID зон") {
                    Button { showingImport = true } label: { Label("Вставить список ID", systemImage: "doc.on.clipboard") }
                    Text("Можно вставить ID через пробелы, запятые или с новой строки.").font(.caption).foregroundStyle(.secondary)
                }
                Section("Адрес проверки") {
                    Text("forum.minecraft-galaxy.ru/zoneinfo/{ID}").font(.footnote).textSelection(.enabled)
                }
            }
            .navigationTitle("Парсер")
            .sheet(isPresented: $showingImport) {
                NavigationStack {
                    VStack {
                        TextEditor(text: $importText).padding(8).background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 12)).padding()
                        Text("Найдено уникальных ID: \(Set(importText.split(whereSeparator: { !$0.isNumber }).compactMap { Int64($0) }).count)").font(.caption).foregroundStyle(.secondary)
                        Spacer()
                    }
                    .navigationTitle("Импорт ID")
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) { Button("Отмена") { showingImport = false } }
                        ToolbarItem(placement: .confirmationAction) { Button("Добавить") { _ = store.addIDs(from: importText); importText = ""; showingImport = false } }
                    }
                }
            }
        }
    }
}

struct HistoryView: View {
    @EnvironmentObject var store: ZoneStore
    var body: some View {
        NavigationStack {
            List(store.zones.filter { $0.lastChecked != nil }.sorted { ($0.lastChecked ?? .distantPast) > ($1.lastChecked ?? .distantPast) }) { zone in
                VStack(alignment: .leading, spacing: 4) {
                    Text("Зона #\(zone.id) — \(zone.status.rawValue)").fontWeight(.medium)
                    Text(zone.lastChecked?.formatted(date: .long, time: .standard) ?? "").font(.caption).foregroundStyle(.secondary)
                    if let error = zone.lastError { Text(error).font(.caption2).foregroundStyle(.orange) }
                }
            }
            .navigationTitle("Последние проверки")
        }
    }
}
