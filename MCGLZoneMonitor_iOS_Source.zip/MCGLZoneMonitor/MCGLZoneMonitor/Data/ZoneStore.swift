import Foundation
import SQLite3
import Combine

final class ZoneStore: ObservableObject {
    @Published private(set) var zones: [Zone] = []
    private var db: OpaquePointer?
    private let queue = DispatchQueue(label: "mcgl.zone.store")

    init() {
        openDatabase()
        load()
    }

    deinit { sqlite3_close(db) }

    private func openDatabase() {
        let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("mcgl-zones.sqlite")
        guard sqlite3_open(url.path, &db) == SQLITE_OK else { return }
        let sql = """
        CREATE TABLE IF NOT EXISTS zones (
            id INTEGER PRIMARY KEY,
            status TEXT NOT NULL DEFAULT 'unknown',
            last_checked REAL,
            http_code INTEGER,
            last_error TEXT
        );
        """
        sqlite3_exec(db, sql, nil, nil, nil)
    }

    func load() {
        queue.async { [weak self] in
            guard let self, let db = self.db else { return }
            var statement: OpaquePointer?
            var result: [Zone] = []
            if sqlite3_prepare_v2(db, "SELECT id,status,last_checked,http_code,last_error FROM zones ORDER BY id DESC", -1, &statement, nil) == SQLITE_OK {
                while sqlite3_step(statement) == SQLITE_ROW {
                    let id = sqlite3_column_int64(statement, 0)
                    let raw = String(cString: sqlite3_column_text(statement, 1))
                    let dateValue = sqlite3_column_type(statement, 2) == SQLITE_NULL ? nil : Date(timeIntervalSince1970: sqlite3_column_double(statement, 2))
                    let code = sqlite3_column_type(statement, 3) == SQLITE_NULL ? nil : Int(sqlite3_column_int(statement, 3))
                    let error = sqlite3_column_text(statement, 4).map { String(cString: $0) }
                    result.append(Zone(id: id, status: ZoneStatus(rawValue: raw) ?? .unknown, lastChecked: dateValue, lastHTTPCode: code, lastError: error))
                }
            }
            sqlite3_finalize(statement)
            DispatchQueue.main.async { self.zones = result }
        }
    }

    func addIDs(from text: String) -> Int {
        let ids = Set(text.split(whereSeparator: { !$0.isNumber }).compactMap { Int64($0) }.filter { $0 > 0 })
        guard !ids.isEmpty, let db else { return 0 }
        queue.sync {
            var statement: OpaquePointer?
            sqlite3_prepare_v2(db, "INSERT OR IGNORE INTO zones(id,status) VALUES(?, 'Не проверена')", -1, &statement, nil)
            for id in ids {
                sqlite3_bind_int64(statement, 1, id)
                sqlite3_step(statement)
                sqlite3_reset(statement)
                sqlite3_clear_bindings(statement)
            }
            sqlite3_finalize(statement)
        }
        load()
        return ids.count
    }

    func update(_ id: Int64, status: ZoneStatus, code: Int?, error: String?) {
        guard let db else { return }
        queue.async {
            var statement: OpaquePointer?
            sqlite3_prepare_v2(db, "UPDATE zones SET status=?,last_checked=?,http_code=?,last_error=? WHERE id=?", -1, &statement, nil)
            sqlite3_bind_text(statement, 1, status.rawValue, -1, SQLITE_TRANSIENT)
            sqlite3_bind_double(statement, 2, Date().timeIntervalSince1970)
            if let code { sqlite3_bind_int(statement, 3, Int32(code)) } else { sqlite3_bind_null(statement, 3) }
            if let error { sqlite3_bind_text(statement, 4, error, -1, SQLITE_TRANSIENT) } else { sqlite3_bind_null(statement, 4) }
            sqlite3_bind_int64(statement, 5, id)
            sqlite3_step(statement)
            sqlite3_finalize(statement)
            self.load()
        }
    }
}
