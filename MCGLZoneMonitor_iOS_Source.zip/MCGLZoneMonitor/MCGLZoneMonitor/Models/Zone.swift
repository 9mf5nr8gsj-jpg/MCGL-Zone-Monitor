import Foundation

enum ZoneStatus: String, Codable, CaseIterable {
    case unknown = "Не проверена"
    case exists = "Существует"
    case deleted = "Удалена"
}

struct Zone: Identifiable, Codable {
    var id: Int64
    var status: ZoneStatus
    var lastChecked: Date?
    var lastHTTPCode: Int?
    var lastError: String?

    var identifiableID: Int64 { id }
}

struct ScanProgress {
    var total: Int = 0
    var completed: Int = 0
    var exists: Int = 0
    var deleted: Int = 0
    var unknown: Int = 0
    var isRunning: Bool = false
    var message: String = "Готов к проверке"
}
